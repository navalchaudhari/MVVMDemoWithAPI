//
//  ViewController.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

