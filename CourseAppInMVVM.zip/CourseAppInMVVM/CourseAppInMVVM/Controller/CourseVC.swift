//
//  CourseVC.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import UIKit

class CourseVC: UIViewController {

    @IBOutlet weak var courseTableView: UITableView!
    
    let courseViewModel : CourseViewModel = CourseViewModel()
    var courseTableData  = [CourseModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupTableView()
        getCourses()
    }
    
    private func getCourses()
    {
        courseViewModel.getCourses { (courseApiResponse) in
            if(courseApiResponse != nil)
            {
                self.courseTableData = courseApiResponse?.map({return CourseModel(course: $0)}) ?? []
                DispatchQueue.main.async {
                    self.courseTableView.reloadData()
                }
            }
        }
    }
    
    fileprivate func setupTableView() {
        courseTableView.register(UINib(nibName: "CourseTableViewCell", bundle: nil), forCellReuseIdentifier: "CourseTableViewCellID")
        courseTableView.rowHeight = UITableView.automaticDimension//UITableViewAutomaticDimension
        courseTableView.estimatedRowHeight = 100
        courseTableView.separatorStyle = .none
    }
}
