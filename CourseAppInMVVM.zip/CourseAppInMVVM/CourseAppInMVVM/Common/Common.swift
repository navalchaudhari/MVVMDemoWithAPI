//
//  Common.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import Foundation


struct ApiEndpoints
{
    static let course = "https://api.letsbuildthatapp.com/jsondecodable/courses"
}
