//
//  CourseVCExtension.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import Foundation
import UIKit

extension CourseVC : UITableViewDataSource
{
    // MARK: - Table view datasource method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return courseTableData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CourseTableViewCellID", for: indexPath) as! CourseTableViewCell

        cell.courseModel = courseTableData[indexPath.row]
        
        return cell
    }
}
