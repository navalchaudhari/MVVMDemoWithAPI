//
//  CourseTableViewCell.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import UIKit

class CourseTableViewCell: UITableViewCell {

    @IBOutlet weak var courseTitle: UILabel!
    @IBOutlet weak var detailText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    var courseModel: CourseModel! {
        didSet {
            courseTitle.text = courseModel.name
            detailText.text = courseModel.detailTextString
            accessoryType = courseModel.accessoryType
        }
    }
    
}
