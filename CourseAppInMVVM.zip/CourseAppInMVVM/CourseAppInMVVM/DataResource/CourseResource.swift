//
//  CourseResource.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import Foundation
struct CourseResource
{
    func getAllCourse(completion: @escaping(_ result : [Course]) -> Void)
    {
        let httpUtility = HttpUtility()

        let courseEndpoint = "\(ApiEndpoints.course)"

        let requestUrl = URL(string: courseEndpoint)!

        httpUtility.getApiData(requestUrl: requestUrl, resultType: [Course].self) { (courseApiResponse) in

            _ = completion(courseApiResponse!)
        }
    }
}
