//
//  CourseViewModel.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import Foundation
import UIKit

struct CourseViewModel
{
    func getCourses(completion: @escaping(_ result: [Course]?)-> Void)
    {
        let courseResource = CourseResource()
        
        courseResource.getAllCourse { (courseApiResponse) in
            _ = completion(courseApiResponse)
        }
    }
}

struct CourseModel
{
    let name: String
    let detailTextString: String
    let accessoryType: UITableViewCell.AccessoryType
    
    // Dependency Injection (DI)
    init(course: Course) {
        self.name = course.name
        
        if course.numberOfLessons > 35 {
            detailTextString = "Lessons 30+ Check it Out!"
            accessoryType = .detailDisclosureButton
        } else {
            detailTextString = "Lessons: \(course.numberOfLessons)"
            accessoryType = .none
        }
    }
}
