//
//  CourseResponseModel.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import Foundation

struct Course: Decodable {
    let id: Int
    let name: String
    let numberOfLessons: Int    
}
