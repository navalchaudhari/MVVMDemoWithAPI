//
//  HttpUtility.swift
//  CourseAppInMVVM
//
//  Created by Naval Chaudhari on 17/12/21.
//

import Foundation

struct HttpUtility
{
    func getApiData<T:Decodable>(requestUrl: URL, resultType: T.Type, completionHandler:@escaping(_ result: T?)-> Void)
    {
        URLSession.shared.dataTask(with: requestUrl) { (responseData, httpUrlResponse, error) in
            if(error == nil && responseData != nil && responseData?.count != 0)
            {
                let decoder = JSONDecoder()
                guard let data = responseData else { return }
                do {
                    let result = try decoder.decode([Course].self, from: data)
                    _=completionHandler((result as! T))
                }
                catch let error{
                    debugPrint("error occured while decoding = \(error)")
                }
            }
        }.resume()
    }
}
