//
//  CourseAppInMVVMTests.swift
//  CourseAppInMVVMTests
//
//  Created by Naval Chaudhari on 17/12/21.
//

import XCTest
@testable import CourseAppInMVVM

class CourseAppInMVVMTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testCourseViewModel() {
        let course = Course(id: 0, name: "My Course Name", numberOfLessons: 10)
        let courseModel = CourseModel(course: course)
        
        XCTAssertEqual(course.name, courseModel.name)
        XCTAssertEqual("Lessons: \(course.numberOfLessons)", courseModel.detailTextString)
        XCTAssertEqual(.none, courseModel.accessoryType)
    }
    
    func testCourseViewModelLessonsOverThreshold() {
        let course = Course(id: 0, name: "My Course Name", numberOfLessons: 100)
        let courseModel = CourseModel(course: course)
        
        XCTAssertEqual("Lessons 30+ Check it Out!", courseModel.detailTextString)
        XCTAssertEqual(.detailDisclosureButton, courseModel.accessoryType)
    }

}
